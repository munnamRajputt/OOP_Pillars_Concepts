package com.example.javasession;

public class InheritanceConceptsClass
{

    //Inheritance concepts
}

class animal extends InheritanceConceptsClass{

public void eats ()
{
    System.out.println("I am eating grass");
}
}

class cow extends animal{

    public void milking() {
        System.out.println("Cow gives milk");
    }

    public static void main(String[] args) {
            cow c = new cow();
            c.eats();
            c.milking();
    }
}