package com.example.javasession;

public class InheritanceAss2Task4 {

    public static void main(String[] args) {

        Furniture fur = new Furniture("wooden furniture");
        fur.furniture();
        Furniture fur_1 = new bedroomFur("wooden furniture", "leather furniture");
        fur_1.furniture();
        Furniture fur_2 = new dinningroom("wooden furniture", "glass furniture");
        fur_2.furniture();

    }
}
class Furniture {
    String name;
    Furniture(String fur){
        this.name = fur;
    }

    public void furniture()
    {
        System.out.println("I am furniture class");
    }
}
class bedroomFur extends Furniture{

    String bedroom_furniture;
    bedroomFur(String fur, String bedroom_furniture) {

        super(fur);
        this.bedroom_furniture = bedroom_furniture;
    }
    public void furniture()
    {
        System.out.println("I am a bedroom furniture");
    }
}
class dinningroom extends Furniture{

    String dinning_furniture;
    dinningroom(String fur, String dinning_furniture) {

        super(fur);
        this.dinning_furniture = dinning_furniture;
    }
    public void furniture()
    {
        System.out.println("I am a dinning room furniture");
    }
}