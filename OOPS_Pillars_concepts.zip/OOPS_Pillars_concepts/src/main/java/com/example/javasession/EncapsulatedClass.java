package com.example.javasession;

public class EncapsulatedClass {

//Encapsulation
    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    //Lets create some variable and hide those fom other classes
    private String salary;
}
