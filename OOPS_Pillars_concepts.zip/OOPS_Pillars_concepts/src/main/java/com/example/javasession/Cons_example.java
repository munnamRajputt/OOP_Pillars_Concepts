package com.example.javasession;

public class Cons_example {

    //Write a program to use objects with constuctor


    String firstName;
    String lastName;
    int age;

    //Student constructor --- By own in the class
    public Cons_example(){
        firstName = "Munnam";
        lastName = "Babar";
        age = 27;
    }

    public static void main(String args[]) {
        System.out.println("Example of Constructor");
        Cons_example StdObject = new Cons_example();
        System.out.println(StdObject.age);
        // 27 -- Output
        System.out.println(StdObject.firstName);
        //Munnam -- Output
    }

}
