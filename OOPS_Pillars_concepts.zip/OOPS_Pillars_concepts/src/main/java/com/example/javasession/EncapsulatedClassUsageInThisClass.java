package com.example.javasession;

public interface EncapsulatedClassUsageInThisClass {
    String name = "Munnam";
    int age =27;

    //accessing another variable implementation using encapsulation
    public static void main(String[] args) {

        EncapsulatedClass ass = new EncapsulatedClass();
        ass.setSalary("105000");


        System.out.println("name of an employee is " + name);
        System.out.println("age of an employee is " + age);
        System.out.println("Salary of an employee is " + ass.getSalary());

    }
}
