package com.example.javasession;

public class AbstractExampleClass
{

    //Example of Abstraction

    public static void main(String[] args) {
        Vehicle newVer = new truck();
        newVer.move();
        newVer.average();

    }
}

 abstract class Vehicle{
    String name;

    public abstract void move();
    public void average()
    {
        System.out.println("I am vehicle and I am going with an average speed");
    }
}
class truck extends Vehicle{

    @Override
    public void move() {
        System.out.println("I am truck & I am moving");
    }
}